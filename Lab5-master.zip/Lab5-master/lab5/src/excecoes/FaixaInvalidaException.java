/* 116210074 - LUCAS VENANCIO DUARTE: LAB 5 - Turma 3 */
package excecoes;

public class FaixaInvalidaException extends Exception{
	
	public FaixaInvalidaException() {
		super ("Numeor da faixa n pode ser menor de 1");
	}

}
