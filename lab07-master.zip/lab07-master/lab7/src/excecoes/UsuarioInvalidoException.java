package excecoes;

public class UsuarioInvalidoException extends Exception {

	public UsuarioInvalidoException() {
		super("Usuario Invalido");
	}
}
