package excecoes;

public class LoginInvalidoException extends Exception {

	public LoginInvalidoException() {
		super("Login invalido");
	}

}
