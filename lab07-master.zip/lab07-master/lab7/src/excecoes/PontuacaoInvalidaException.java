package excecoes;

public class PontuacaoInvalidaException extends Exception {
	public PontuacaoInvalidaException() {
		super("pontuacao invalida");
	}

}
