package excecoes;

public class PrecoInvalidoException extends Exception {

	public PrecoInvalidoException() {
		super("Preco Invalido");
	}

}
