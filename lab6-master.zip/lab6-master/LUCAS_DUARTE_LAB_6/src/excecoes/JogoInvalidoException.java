package excecoes;

public class JogoInvalidoException extends Exception {

	public JogoInvalidoException() {
		super("Jogo invalido");
	}
}
