package excecoes;

public class EstiloInvalidoException extends Exception {

	public EstiloInvalidoException() {
		super("Estilo do jogo invalido");
	}

}
