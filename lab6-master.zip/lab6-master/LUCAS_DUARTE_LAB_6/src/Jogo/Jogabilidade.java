package Jogo;

public enum Jogabilidade {

	ONLINE, OFFLINE, MULTIPLAYER, COOPERATIVO, COMPETITIVO;

}
